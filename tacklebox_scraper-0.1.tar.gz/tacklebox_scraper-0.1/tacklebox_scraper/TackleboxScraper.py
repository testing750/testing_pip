from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import json
import tacklebox_scraper

#parent class
class TackleBoxScraper:
    """
    Parent class for all Tacklebox Scrapers. Initializes and manages the selenium driver for the scraper

    :param url: the url which will be used to initialize the selenium webdriver
    :param debug: a flag determining whether debug output will be shown or not. If true selenium is run headless
    """
    def __init__(self, url, debug=False):
        self.debug = debug
        self.url = url
        self.finalSpeakerList = []
        self.opts = Options()
        self.opts.add_argument("user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0")

        # If debug is False it will open a chrome window, otherwise it will be in headless mode
        # Needs to be set to false for proeuction enviroment
        if debug == False:
            self.opts.add_argument('--headless')
            self.opts.add_argument('--no-sandbox')
            self.opts.add_argument('--disable-dev-shm-usage')

        # Setting up ChromeDriver
        self.driver = webdriver.Chrome(options=self.opts)

    def loadJson(self, path):
        """
        load a saved JSON file instead of starting a new scrape

        :param path: The path to the JSON file
        """
        with open(tacklebox_scraper.__file__[:-11]+"data/"+path ,"r") as f:
            self.finalSpeakerList = json.load(f)
        print("Loaded")

    def isPersonInFinalList(self, person, company):
        """
        Check if a person is contained in the finalSpeakerList for this object

        :param person: The string name of the person
        :param company: The string name of the company the person works for
        :return: A boolean, True if the person is contained, False otherwise
        """
        for i in range(len(self.finalSpeakerList)):
            print("checking if "+person+" "+company+" is: "+self.finalSpeakerList[i]["name"]+" "+self.finalSpeakerList[i]["company"])
            if self.finalSpeakerList[i]["name"].replace(" ","") == person.replace(" ","") and self.finalSpeakerList[i]["company"].replace(" ","") == company.replace(" ",""):
                return True
        return False

    def getPersonAtIndex(self,person,company):
        """
        Return the entry from finalSpeakerList for the given person and company

        :param person: The string name of the person
        :param company: The string name of the company
        :return: The entry from finalSpeakerList for the given person and company
        """
        for i in range(len(self.finalSpeakerList)):
            print("checking if "+person+" "+company+" is: "+self.finalSpeakerList[i]["name"]+" "+self.finalSpeakerList[i]["company"])
            if self.finalSpeakerList[i]["name"].replace(" ","") == person.replace(" ","") and self.finalSpeakerList[i]["company"].replace(" ","") == company.replace(" ",""):
                return i
        raise Exception("Person not in list")

    def checkData(self):
        """
        Quality control check for the entries in finalSpeakerList.
        Checks if there are duplicate entries for one person. Also checks for entries missing a name
        """
        print("Checking Data")
        self.itter = 0
        self.noNamePeople = []
        for i in range(len(self.finalSpeakerList)):
            # First check if there are duplicates of a person and there name
            self.personAppearance = []
            for j in range(len(self.finalSpeakerList)):
                self.itter+=1
                # print("Checking "+str(self.itter))
                if self.finalSpeakerList[i]["name"]+self.finalSpeakerList[i]["company"] == self.finalSpeakerList[j]["name"]+self.finalSpeakerList[j]["company"]:
                    self.personAppearance.append(j)
            if len(self.personAppearance) > 1:
                print("Issue with "+str(self.finalSpeakerList[i]))

            # Check if someone has no mane
            if self.finalSpeakerList[i]["name"] == "":
                self.noNamePeople.append(i)
        for self.lackofPerson in self.noNamePeople:
            print("Deleting an entry which has no name")
            del self.finalSpeakerList[self.lackofPerson]
            


    def isPageLoaded(self,element,selector,driver=None):
        """
        Checks if a page has successfully loaded by searching for a specified html element in the page

        :param element: How to search. This can be one of 'id', 'class', or 'tag'
        :param selector: The search criteria corresponding to the search method selected using the element param
        :param driver: Optional, the selenium driver to use for the search
        :return: boolean, True if the page is loaded, False otherwise
        """
        print("Checking if page is loaded")
        if driver == None:
            driver = self.driver
        if element == "id":
            try:
                driver.find_element_by_id(selector)
                return True
            except:
                try:
                    if driver.find_element_by_tag_name("h1").text == "Sorry,":
                        time.sleep(5)
                        driver.refresh()
                except:
                    pass
                return False

        elif element == "class":
            try:
                driver.find_element_by_class_name(selector)
                return True
            except:
                try:
                    if driver.find_element_by_tag_name("h1").text == "Sorry,":
                        time.sleep(5)
                        driver.refresh()
                except:
                    pass
                return False

        elif element == "tag":
            try:
                driver.find_element_by_tag_name(selector)
                return True
            except:
                try:
                    if driver.find_element_by_tag_name("h1").text == "Sorry,":
                        time.sleep(5)
                        driver.refresh()
                except:
                    pass
                return False

    def startScrape(self):
        """
        Start the page scrape. This method is always overridden when implementing child classes
        :return:
        """
        return {"url":self.url}
    
    def getSpeakers(self):
        """
        Return the finalSpeakerList variable
        :return: the JSON-like object from finalSpeakerList
        """
        return self.finalSpeakerList





                    




    











