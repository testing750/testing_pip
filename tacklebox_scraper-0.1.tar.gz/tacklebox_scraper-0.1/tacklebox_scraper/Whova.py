import time
import selenium
from selenium.webdriver.common.keys import Keys
import configparser

import TackleboxScraper

class Whova(TackleboxScraper.TackleBoxScraper):
    def __init__(self, url, debug=False):
        super().__init__(url, debug=debug)
        config = configparser.ConfigParser()
        config.read("config.ini")
        self.username = config["MEOPARASM"]["username"]
        self.password = config["MEOPARASM"]["password"]

    def startScrape(self):
        """
        Runs the Whova scraper
        :rtype: object
        """
        self.driver.get(self.url)
        while not self.isPageLoaded("class", "sign-in-text"):
            time.sleep(.1)
            print("Page loading text")

        self.__login()
        while not self.isPageLoaded("class", "whova-tabs"):
            time.sleep(.1)
            print("Page loading text")

        whova_date_tab_count = len(self.__get_whova_date_tabs())
        sessions = []
        for i in range(whova_date_tab_count):
            tab = self.__get_whova_date_tabs()[i]
            self.driver.execute_script("arguments[0].click();", tab)
            session_count = len(self.__get_sessions())
            if session_count > 0:
                for r in range(session_count):
                    tab = self.__get_whova_date_tabs()[i]
                    self.driver.execute_script("arguments[0].click();", tab)
                    while "active" not in tab.get_attribute("class"):
                        time.sleep(.2)
                        tab.click()
                    print("Sessions: " + str(session_count) + " iter: " + str(r))
                    try:
                        session = self.__get_sessions()[r]
                    except IndexError:
                        time.sleep(.5)
                        session = self.__get_sessions()[r]
                        print(self.__get_sessions())
                    sessions.append(self.__get_session_info(session))
        speaker_list = self.__transform_session_data(sessions)
        self.finalSpeakerList = speaker_list

    def __login(self):
        """
        Logs in to the whova site specified
        """
        username_field = self.driver.find_element_by_id("webapp-email")
        password_field = self.driver.find_element_by_id("webapp-password")

        username_field.send_keys(self.username)
        password_field.send_keys(self.password)

        username_field.send_keys(Keys.ENTER)

    def __get_whova_date_tabs(self):
        """
        Scrapes the list of tabs from the whova main page
        :rtype: object
        """
        tab_container = self.driver.find_element_by_class_name("whova-tabs-inner")
        tabs = tab_container.find_elements_by_class_name("agenda-date-tab")
        return tabs

    def __get_sessions(self):
        """
        Scrapes the list of sessions for the currently selected whova tab
        :rtype: object
        """
        sessions = self.driver.find_elements_by_class_name("session")
        return sessions

    def __get_session_info(self, session):
        """
        Scrape the session info for the specified session
        :param session:
        :return:
        """
        clickable_session_title = session.find_element_by_class_name("session-title")
        if clickable_session_title:
            clickable_session_title.click()

        while not self.isPageLoaded("class", "session-details-content"):
            time.sleep(.1)
            print("Page loading text")

        session_details_content = self.driver.find_element_by_class_name("session-details-content")
        session_info = {}
        if session_details_content:
            session_info["title"] = session_details_content.find_element_by_id("session-details-title").text
            session_info["description"] = session_details_content.find_element_by_class_name("session-desc").text
            speaker_info_elements = session_details_content.find_elements_by_class_name("speaker-info")
            speaker_name_elements = session_details_content.find_elements_by_class_name("speaker-name")
            session_info["speakers"] = []
            for speaker_info in speaker_info_elements:
                speaker_name = ""
                speaker_company = ""
                speaker_job_title = ""
                if speaker_info.find_elements_by_class_name("speaker-name"):
                    speaker_name = speaker_info.find_element_by_class_name("speaker-name").text
                if speaker_info.find_elements_by_class_name("speaker-title"):
                    speaker_job_title = speaker_info.find_element_by_class_name("speaker-title").text
                if speaker_info.find_elements_by_class_name("speaker-aff"):
                    speaker_company = speaker_info.find_element_by_class_name("speaker-aff").text
                session_info["speakers"].append({
                    "name": speaker_name,
                    "jobTitle": speaker_job_title,
                    "company": speaker_company
                })
        time.sleep(1)
        self.driver.execute_script("window.history.go(-1)")
        while not self.isPageLoaded("class", "whova-tabs"):
            time.sleep(.1)
            print("Page loading text")

        video_close_button = self.driver.find_element_by_id("pip-close-btn")
        if video_close_button:
            try:
                video_close_button.click()
            except selenium.common.exceptions.ElementNotInteractableException:
                pass

        return session_info

    def __transform_session_data(self, session_data):
        """
        Transforms the scrapers data structure into the standard required for Tacklebox scrapers
        :param session_data:
        :return:
        """
        speakers = {}
        for session in session_data:
            for speaker in session["speakers"]:
                speaker_name = speaker["name"]
                if speaker["name"] not in speakers:
                    speakers[speaker_name] = speaker
                    speakers[speaker_name]["presentations"] = []
                speakers[speaker_name]["presentations"].append({
                    "pTitle": session["title"],
                    "pDetails": [session["description"]]
                })
        return speakers


if __name__ == "__main__":
    URL = "https://whova.com/portal/webapp/meopa_202009/Agenda"
    whova = Whova(URL, debug=True)
    whova.startScrape()

