from urllib.request import Request, urlopen
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common import by
import time, datetime
import re
import json
import TackleboxScraper


class Oceanology(TackleboxScraper.TackleBoxScraper):
    def __init__(self,url,debug=False):
        super().__init__(url,debug=debug)

    #main page or details page
    def isPageLoaded(self,page,driver=None):
        if driver == None:
            
            driver = self.driver
        if page == "main":
            if driver.find_elements_by_class_name("resultItem")[-1].find_element_by_tag_name("h3").find_element_by_tag_name("a").text == "":
                return False
            else:
                return True
        if page == "details":
            try:
                #time.sleep(1)
                if driver.find_elements_by_class_name("lastName")[-1].find_element_by_tag_name("a").text == "":
                    return False
                else:
                    return True
            except:
                print("skip")
                return "skip"

    def __getSpeakerInfo(self,person):
        self.speakerInfo = {
            "name":"",
            "company":"",
            "jobTitle":"",
            "presentations":[{
                "pTitle":"",
                "pDetails":[]
            }]
        }
        #If True, then this person is a speaker, and will get returned, else it will return False
        if person.find_element_by_class_name("role").text == "Speaker":
            self.speakerInfo["name"] = person.find_element_by_class_name("lastName").find_element_by_tag_name("a").text
            self.speakerInfo["company"] = person.find_element_by_class_name("company").text
            self.speakerInfo["jobTitle"] = person.find_element_by_class_name("jobTitle").text
            self.speakerInfo["presentations"][0]["pTitle"] = self.driver.find_element_by_class_name("title").text
            for self.paragraph in self.driver.find_element_by_class_name("richtext").find_elements_by_tag_name("p"):
                if self.paragraph.get_attribute("class") == "":
                    self.speakerInfo["presentations"][0]["pDetails"].append(self.paragraph.text.replace("\n",""))
            return self.speakerInfo
        else:
            return False


    def startScrape(self):
        self.driver.get(self.url)

        while not self.isPageLoaded("main",driver=self.driver):
            time.sleep(.1)
            print("Page loading text")

        #Get the number of pages
        self.pages = []
        self.startPageCount = False
        for self.item in self.driver.find_element_by_class_name("pagination").find_elements_by_tag_name("li"):
            print(self.item.get_attribute("class"))
            if self.item.get_attribute("class") == "gButton":
                break
            elif self.startPageCount == True:
                self.pages.append(self.item.find_element_by_tag_name("a").get_attribute("href"))
            if self.item.get_attribute("class") == "bButton" or self.item.get_attribute("class") == "bButton bButton-hidden":
                self.startPageCount = True

        #Getting a list of all the presentaion links to later check speaker information
        self.linkList = []
        for i in range(len(self.pages)):

            self.driver.get(self.pages[i])

            while not self.isPageLoaded("main",driver=self.driver):
                time.sleep(.1)
                print("Page loading text")

            self.rows = self.driver.find_elements_by_class_name("resultItem")

            for self.item in self.rows:
                self.linkList.append(self.item.find_element_by_tag_name("h3").find_element_by_tag_name("a").get_attribute("href"))
        self.skip = False
        for self.link in self.linkList:
            self.driver.get(self.link)
            while not self.isPageLoaded("details",driver=self.driver):
                time.sleep(.1)
                if self.isPageLoaded("details",driver=self.driver) == "skip":
                    self.skip = True
                print("Page loading text")
            if self.skip == True:
                self.skip = False
            else:
                for self.person in self.driver.find_elements_by_class_name("contributorSessionRoleDetail"):

                    #If the person is a speaker it will check if they already exsist in the mastrer list
                    #If they do, it will add this presenation to the list, if not, it will create a new list entry
                    self.tempSpeakerInfo = self.__getSpeakerInfo(self.person)
                    self.personInList = False
                    if self.tempSpeakerInfo:
                        if self.isPersonInFinalList(self.tempSpeakerInfo["name"],self.tempSpeakerInfo["company"]):
                            for i in range(len(self.finalSpeakerList)):
                                if (self.finalSpeakerList[i]["name"]+self.finalSpeakerList[i]["company"]).replace(" ","") == (self.tempSpeakerInfo["name"]+self.tempSpeakerInfo["company"]).replace(" ",""):
                                    self.finalSpeakerList[i]["presentations"].append(self.tempSpeakerInfo["presentations"][0])
                                    self.personInList = True
                        if self.personInList == False:
                            self.finalSpeakerList.append(self.tempSpeakerInfo)
                print(self.finalSpeakerList)
                for self.person in self.finalSpeakerList:
                    print(self.person["name"])
                    for self.details in self.person["presentations"][0]["pDetails"]:
                        print(self.details)

                #time.sleep(5)
        for i in range(len(self.finalSpeakerList)):
            print(self.finalSpeakerList[i])



if __name__ == "__main__":

    oceanology = Oceanology("https://www.oceanologyinternational.com/sessions#",debug=True)
    #oceanology.startScrape()
    #oceanology.loadJson("oceanologySpeakers.json")
    allSpeakers = oceanology.getSpeakers()
    oceanology.checkData()
    '''
    with open("speakers","w") as fout:
        json.dump(allSpeakers,fout)
'''
        
