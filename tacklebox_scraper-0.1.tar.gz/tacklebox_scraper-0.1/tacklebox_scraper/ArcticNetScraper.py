from urllib.request import Request, urlopen
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common import by
import time, datetime
import re
import json
from tacklebox_scraper import TackleboxScraper


class ArcticNet(TackleboxScraper.TackleBoxScraper):
    def __init__(self,url,debug=False,scrollDelay=.5,webScrollTimeOut=5,loadDelay=5):
        super().__init__(url,debug=debug)
        self.loadDelay = loadDelay
        #This is here because you need to scroll down the page for ArcticNet because of their optimization
        #Time in seconds
        self.scrollDelay = scrollDelay
        #First number is in minutes
        #There is a loop which will eventually be cancled if it runs into some kind of error
        self.webScrolTimeOut = int((webScrollTimeOut * 60)/self.scrollDelay)

    def checkData(self):
        super().checkData()
        #Check if the description is empty for Poster Sessions, and Topical Sessions
        print("other chjecking")
        self.problematicPeople = []
        for i in range(len(self.finalSpeakerList)):
            for j in range(len(self.finalSpeakerList[i]["presentations"])):
                if self.finalSpeakerList[i]["presentations"][j]["pDetails"] == "" and (self.finalSpeakerList[i]["presentations"][j]["type"] == "Poster Presentation" or self.finalSpeakerList[i]["presentations"][j]["type"] == "Topical Session"):
                    self.problematicPeople.append([i,j])
                    print(self.finalSpeakerList[i]["name"]+" had an error in the details")

    #private function to segment code. This function takes the speakers profile page and add all relavent info to dict
    def __getSpeakerInfo(self,url):
        #Opening a new chrome window to get speaker information
        self.driverPerson =webdriver.Chrome(options=self.opts)
        self.driverPerson.get(url)

        #Wait for JS to load
        #time.sleep(self.loadDelay)

        while not self.isPageLoaded("class","card-content",driver=self.driverPerson):
            time.sleep(.1)
        time.sleep(self.loadDelay)

        print("Getting person info")

        self.speakerInfo = {
            "name":"",
            "company":"",
            "presentations":[]
        }
        self.speakerInfo["name"] = self.driverPerson.find_element_by_class_name("person-name").text
        if self.driverPerson.find_element_by_class_name("person-company").text == "":
            self.speakerInfo["company"] = ""
        else:
            self.speakerInfo["company"] = self.driverPerson.find_element_by_class_name("person-company").text

        #Click the "OK" button on the alert which usually pops up
        try:
            self.alerts = self.driverPerson.find_elements_by_class_name("button-card-footer-half-width")
            for self.alert in self.alerts:
                if self.alert.text == "OK":
                    self.alert.click()
        except:
            pass

        #Click all the presentations they are apart of
        self.cardList = self.driverPerson.find_elements_by_class_name("card-content")
        for i in range(len(self.cardList)):
            self.cardList = self.driverPerson.find_elements_by_class_name("card-content")
            try:
                self.cardList[i].click()
                print("Going In")
            except:
                try:
                    self.alerts = self.driverPerson.find_elements_by_class_name("button-card-footer-half-width")
                    for self.alert in self.alerts:
                        if self.alert.text == "OK":
                            self.alert.click()
                    self.cardList[i].click()
                except:
                    raise Exception("Error when clicking Card")


            
            while not self.isPageLoaded("class","person-list",driver=self.driverPerson):
                time.sleep(.1)
            time.sleep(self.loadDelay)
            self.personList = self.driverPerson.find_element_by_class_name("person-list")
            self.personList = self.personList.find_elements_by_tag_name("li")

            #Gets all the name in the "Speaker" Section to see if this person is a speaker or not
            self.tempNameList = []
            for self.person in self.personList:
                self.tempNameList.append(self.person.find_element_by_class_name("person-name").text+" "+self.person.find_element_by_class_name("person-company").text)
            if self.speakerInfo["name"]+" "+self.speakerInfo["company"] in self.tempNameList:
                #This means that they are a speaker and not a Co-Chair
                '''
                self.titleList = self.driverPerson.find_element_by_tag_name("h1").text.split("-")
                del self.titleList[0]
                self.pTitle = ""
                for i in range(len(self.titleList)):
                    self.pTitle += self.titleList[i]+"-"
                self.pTitle = self.pTitle[:-1]
                '''

                self.tempPresentationInfo = {
                    "type":"",
                    "pTitle":"",
                    "pSpecificTitle":[],
                    "pDetails":"",
                }
                
                self.pTitle = self.driverPerson.find_element_by_tag_name("h1").text
                self.pTitle = re.sub('\D{3}\d{2}-',"",self.pTitle)
                self.pTitle = re.sub('\D{2}\d{2}-',"",self.pTitle)
                self.tempPresentationInfo["pTitle"] = self.pTitle
                
                #Checking if the session is Topical or poster
                self.whichSession = ""
                for self.pTag in self.driverPerson.find_elements_by_class_name("MuiTypography-root"):
                    if self.pTag.text == "Topical Session" or self.pTag.text == "Poster Presentation" or self.pTag.text == "Plenary Session":
                        self.whichSession = self.pTag.text
                        break

                if self.whichSession == "Poster Presentation" or self.whichSession == "Plenary Session":
                    self.tempPresentationInfo["type"] = self.whichSession
                    try:
                        self.tempPresentationInfo["pDetails"] = self.driverPerson.find_element_by_class_name("details-block-content").text.replace("\n","")
                    except:
                        self.tempPresentationInfo["pDetails"] = ""
                    self.tempPresentationInfo["pSpecificTitle"].append(self.driverPerson.find_element_by_tag_name("h1").text.replace("\n",""))
                elif self.whichSession == "Topical Session" :
                    self.tempPresentationInfo["type"] = "Topical Session"
                    self.paragraphs = self.driverPerson.find_element_by_class_name("details-block-content").find_elements_by_tag_name("p")
                
                    self.gotDetails = False
                    for j in range(len(self.paragraphs)):
                        if len(self.paragraphs[j].text) > 30 and self.gotDetails == False:
                            self.tempPresentationInfo["pDetails"] = self.paragraphs[j].text
                            self.gotDetails = True
                        if self.speakerInfo["name"] in self.paragraphs[j].text:
                            self.tempPresentationInfo["pSpecificTitle"].append(self.paragraphs[j-1].text)
                else:
                    self.tempPresentationInfo["type"] = "Other Type of Session"
                    self.tempPresentationInfo["pSpecificTitle"].append(self.driverPerson.find_element_by_tag_name("h1").text.replace("\n",""))
                self.speakerInfo["presentations"].append(self.tempPresentationInfo)

                                

            

            self.driverPerson.execute_script("window.history.go(-1)")
            print("Going Back")
            print(self.speakerInfo)

            #Waiting for page to load
            while not self.isPageLoaded("class","card-content",driver=self.driverPerson):
                time.sleep(.1)
            time.sleep(self.loadDelay)



        for i in range(len(self.speakerInfo["presentations"])):
                    print(self.speakerInfo["name"]+" was a speaker at: "+str(self.speakerInfo["presentations"][i]))
        self.driverPerson.quit()
        return self.speakerInfo



    def startScrape(self):
        self.driver.get(self.url)

        #Time.sleep so that Chrome can finish loading all the JS
        #time.sleep(self.loadDelay)

        while not self.isPageLoaded("class","menu-nav-item",driver=self.driver):
            time.sleep(.1)
        time.sleep(self.loadDelay)
        #time.sleep(2)

        #Finding all the elements of the HTML page that are an 'a' tag, then parsing it with BS
        self.aTags = self.driver.find_elements_by_tag_name("a")

        for self.item in self.aTags:
            if self.item.text == "Speakers":
                self.speakerUrl = self.item.get_attribute("href")
                print("got speakers tab")
                break
        
        self.driver.get(self.speakerUrl)
        #Sleeping so the page can load all the JS
        while not self.isPageLoaded("class","person-list-item",driver=self.driver):
            time.sleep(.1)
        time.sleep(1)

        #This needs to eb set to 1 so it's not the same as the initial scroll offset
        self.oldPageHeight = 1
        for i in range(self.webScrolTimeOut):
            self.driver.execute_script("window.scrollTo(0,"+str(i*200)+")")
            self.currentPageheight = self.driver.execute_script("return window.pageYOffset;")


            #This gives the website time to update the JS
            time.sleep(self.scrollDelay)

            #This gets every person and their profile URL and sends each one off to the function to get all their info
            self.personList = self.driver.find_elements_by_class_name("person-list-item")
            
            
            
            #To determin who to start at, so we don't get douplicates
            if len(self.finalSpeakerList) == 0:
                self.personToStartAt = 0
            else:
                for j in range(len(self.personList)):
                    if not self.isPersonInFinalList(self.personList[j].find_element_by_class_name("person-name").text,self.personList[j].find_element_by_class_name("person-company").text):
                        self.personToStartAt = j
                        break
                    self.personToStartAt = len(self.personList)
                    
            if self.personToStartAt == len(self.personList):
                print("ISSUES")
                time.sleep(5)


            for j in range(self.personToStartAt,len(self.personList)):
                self.personList = self.driver.find_elements_by_class_name("person-list-item")
                self.finalSpeakerList.append(self.__getSpeakerInfo(self.personList[j].get_attribute("href")))

                time.sleep(.5)
                for m in range(len(self.finalSpeakerList)):
                    print(self.finalSpeakerList[m]["name"])

            if self.currentPageheight == self.oldPageHeight:
                print(self.finalSpeakerList)
                break
            self.oldPageHeight = self.currentPageheight


        if self.debug == True:
            self.getPosters()

    def errorCheck(self,driver):
        try:
            self.alerts = driver.find_elements_by_class_name("button-card-footer-half-width")
            for self.alert in self.alerts:
                if self.alert.text == "OK":
                    self.alert.click()
        except:
            print("No error card to click")
         

    def getPosters(self):
        #Now to get the rest of the poster presenters

        #Going to the posters webpage
        self.driver.get(self.url)

        #Time.sleep so that Chrome can finish loading all the JS
        #time.sleep(self.loadDelay)

        while not self.isPageLoaded("class","menu-nav-item",driver=self.driver):
            time.sleep(.1)
        time.sleep(self.loadDelay)
        #time.sleep(2)

        #Finding all the elements of the HTML page that are an 'a' tag, then parsing it with BS
        self.aTags = self.driver.find_elements_by_tag_name("a")

        for self.item in self.aTags:
            if self.item.text == "Posters":
                self.postersUrl = self.item.get_attribute("href")
                print("got speakers tab")
                break
        
        self.driver.get(self.postersUrl)
        #Sleeping so the page can load all the JS
        while not self.isPageLoaded("class","button-group-link",driver=self.driver):
            time.sleep(.1)
        time.sleep(.5)

        #Now we are loaded into the posters page
        #Getting the Table view link
        for self.button in self.driver.find_elements_by_class_name("button-group-link"):
            for self.span in self.button.find_elements_by_tag_name("span"):
                if self.span.text == "Table":
                    self.driver.get(self.button.get_attribute("href"))
                    break

        while not self.isPageLoaded("class","timeline-session-card-bg",driver=self.driver):
            time.sleep(.1)
        time.sleep(.1)

        #We are going to click some elements, so it's time to check if the popup has appeared
        self.errorCheck(self.driver)
        #Now that we are in the table view we are going to click all the descriptions
        self.posterHrefList = [] 
        for self.timeCard in self.driver.find_elements_by_class_name("timeline-session-card"):
            #I have gotten a pup up, so we are going to try and make sure there isn't an error
            try:
                self.timeCard.click()
            except:
                self.errorCheck(self.driver)
                self.timeCard.click()
            #The descriptions is now being showed in a popup
            while not self.isPageLoaded("class","schedule-option",driver=self.driver):
                time.sleep(.1)
            time.sleep(.1)
            #Checking if the description matches any already in the final list
            #print(self.driver.find_element_by_class_name("session-details-modal-description").text)
            self.alreadyInList = False
            self.itter = 0
            for self.person in self.finalSpeakerList:
                for self.pres in self.person["presentations"]:
                    #This first conditional is just so the program doesn't have to comapre as many large strings
                    if self.pres["pDetails"].replace(" ","")[:10] == self.driver.find_element_by_class_name("session-details-modal-description").text.replace(" ","")[:10]:
                        print("Close Match!")
                        if self.pres["pDetails"].replace(" ","") == self.driver.find_element_by_class_name("session-details-modal-description").text.replace(" ",""):
                            print("This poster is already in our system")
                            self.alreadyInList = True
                            break
                if self.alreadyInList == True:
                    break
            if self.alreadyInList == False:
                print("Adding the link to the list of links to later go through")
                if self.driver.find_element_by_class_name("schedule-option").text == "Go to Session Page":
                    self.posterHrefList.append(self.driver.find_element_by_class_name("schedule-option").get_attribute("href"))
            self.driver.find_element_by_class_name("session-details-modal-description").click()

        if self.debug == False:
            self.goThroughLinks()        
    
    def goThroughLinks(self,linkList=""):

        if linkList != "":
            self.posterHrefList = linkList

        print("Going through all the poster links")
        for self.link in self.posterHrefList:
            self.driver.get(self.link)
            while not self.isPageLoaded("class","details-block-content",driver=self.driver):
                time.sleep(.1)
            time.sleep(.1)
            if len(self.driver.find_elements_by_class_name("person-list-item")) > 0:
                self.personInList = False
                for self.person in self.driver.find_elements_by_class_name("person-list-item"):
                    if self.isPersonInFinalList(self.person.find_element_by_class_name("person-name").text,self.person.find_element_by_class_name("person-company").text):
                        self.personInList = True
                        #Putting their info into the lsit if they are already in it
                        print("Apending to list")
                        self.personIndex = self.getPersonAtIndex(self.person.find_element_by_class_name("person-name").text,self.person.find_element_by_class_name("person-company").text)
                        self.finalSpeakerList[self.personIndex]["presentations"].append({
                            "type":"Poster Presentation",
                            "pTitle":self.driver.find_element_by_tag_name("h1").text,
                            "pSpecificTitle":[self.driver.find_element_by_class_name("details-block-content").text],
                            "pDetails":self.driver.find_element_by_class_name("details-block-content").text,
                        })
                        break
                if self.personInList == False:
                    print("added new list entry")
                    self.finalSpeakerList.append({
                        "name":self.person.find_element_by_class_name("person-name").text,
                        "company":self.person.find_element_by_class_name("person-company").text,
                        "presentations":[{
                                "type":"Poster Presentation",
                                "pTitle":self.driver.find_element_by_tag_name("h1").text,
                                "pSpecificTitle":[self.driver.find_element_by_class_name("details-block-content").text],
                                "pDetails":self.driver.find_element_by_class_name("details-block-content").text,
                            }]
                    })

if __name__ == "__main__":
    linkList = '''https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/4dcb86a6-af25-4fa5-9311-fa826b0290db
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/15b0e05c-e5d7-4609-9bd6-2067e22109ea
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/675acf04-037a-4384-b0d9-b40f18febfdf
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8452aca0-6108-4858-ab30-f3888d09e32b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/94c3f974-e176-4dae-8765-3888788e8260
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/db4e1626-fe17-4fb5-be8f-a875f468adc4
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/1c7f217a-6baa-44da-a054-9cd5fee6d43b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2cabf29a-54f7-4168-b3d2-d81cf9a2daa0
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/47847cf8-8756-4d1e-84b0-29127d56a8a4
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/b0ba05eb-1478-47ff-a4f0-73814343e3f4
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/fbfcde86-ec41-41d2-a7bf-373f31267a62
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/0d05ecc5-4482-4da4-88e6-d1b64d7d2d18
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/819295f6-8c98-41df-93dd-905298a224bf
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/929b6411-daa1-4151-8bff-6075268fd1c3
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/a2ab99a1-ab2c-40ed-a736-355ffff81b08
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/ea2340f5-3f48-422d-b66c-976c25feea5e
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2201572a-1510-4911-a721-0e5be3496764
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/28845a61-a6cf-48aa-b2a1-e355d5da23e4
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/4d3e8294-afe3-4d79-93d8-771699c2dfce
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/50f25efa-8e5c-4482-9bee-bf31367c0e9c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/dac86e70-acc8-4b58-9fc6-298929a2e4f2
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f3a58033-f64e-4ab7-8aa1-79e379358ba1
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/003057f1-7767-4c46-8bce-80c15df8b5bf
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/529a7153-4a82-4c7b-98ad-056795e66be5
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/ade18371-6522-4177-90ad-d871aaa6d50b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/c006e1e6-d096-4c48-a888-9d8bcd73a54d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d7c35cd2-c294-4271-a55c-0494ad0ba515
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/fb774e6c-4de3-4fc9-aeb7-4e41ee84554d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/19114305-fd34-42d1-a0b3-1c8aa5473b2b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/4f69b014-ede5-4130-91bf-410b1c8024af
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/7aae8317-1766-481f-abb0-36e5c59cd636
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/90d3ff26-fa86-406d-a96e-ec72740d212a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/a2a244b2-fcc6-4fd1-9f23-0fdad2a071de
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/a8db837e-aac1-4110-877c-1e109cfc4cae
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f90aca32-0777-4e5c-b649-5ae4adf68aaa
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/6dfdae4d-524c-47bc-89a9-56935d52b0e4
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/7c4852ff-8923-4674-a19e-d948b75d8757
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/b0ec36ec-64ee-4021-8d08-0b93205359a4
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8fe498df-3457-443b-a76b-e15c450eca58
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/e9308c8b-2064-43fb-b007-c2a56887359c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f80fb606-6fef-4d91-aa3e-028f59da103c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/26163d32-ae21-42ac-8b54-54e878b84c71
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/55ec454f-0af3-40b6-8c22-e7378c257677
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/70f69506-88ba-4cc3-b341-77dfe9e17286
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/93a29c90-f321-4973-a37e-c3facb737d4f
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/94fa88fc-84be-4473-a0da-71917d55efb0
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/ab3f859c-53f2-430c-8007-595e6d8fd141
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/ea536d36-7fda-427a-a5a5-04ef2593ed8b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2fdfa4e9-d795-45aa-bb26-5b955135f1f8
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/377b069d-038d-4b4a-8442-c8b271a2101e
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/73dd1bcc-6dfd-4033-a3cb-ab7dc3976a91
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/baf933df-3ad2-4b2a-b002-a1b463e3e62e
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d9f0e42e-065d-4853-8b53-fc7b3c161c7f
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/0cedb8c7-e28c-4d32-b73a-16914e7b82fd
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/20213b34-1a7a-4e93-8e52-67b0cee58f27
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/48e1c495-ffb5-4458-86ac-c6f30c25f6c1
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8ba521c8-cf9b-4c88-aba6-0a9b0dfd6044
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/a4ea55a1-4594-4959-98bf-2f81f1677ef0
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/aa6dff86-a42e-49f4-a089-b59fbc4c3331
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/fbc76f93-d356-40a5-9b8a-f96c4816b876
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/08631419-1807-445e-b846-885aebfc0c77
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/236f995c-7aa1-45c2-abe1-9c3f9690f77d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/37201665-5719-4387-9e0d-ef1440547bb3
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/3941c8d0-8230-4cc8-af79-1a004625145b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/bd0268d2-4e90-4d73-a6dc-6df4268b2ca7
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/c4e25f50-b32e-4982-9ece-4d995f07c402
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/cb844e56-8923-42f0-9a4b-84317d6f4a74
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/0335b199-3e87-4938-ba51-f71c3521fc01
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/1dca4e7b-831c-4f8a-8e73-a492166fc8cb
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2ecdb929-8c15-4fdf-a18a-3ac0c61a8d7a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f15d4cbd-c39f-47c5-a211-5af506dd0fc5
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f72770f5-1422-400e-84cb-7b33304491c7
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/038e017d-fcfa-4916-963f-7ed2164cf63b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/587b2e44-7e1e-4b84-b791-0c4c49098829
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8c04e23c-b790-48a4-b5bd-a58fadf346a4
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/952bda15-a11e-4c99-926b-f0db8093ee86
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/9b514cbf-4134-441c-87cc-70cc6addb757
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d47b6e26-6004-4cd9-8e10-31659e3fd67c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f618fb55-7063-4d78-849f-c5887ad9acc6
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/6afc41f0-6512-4c3e-ab62-d2db02d752ef
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/72ecdc9d-66d8-4967-8c9c-cbf4b7dcf92b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/abfadb40-4a8f-4a94-be60-22d531baab3b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d7a01b37-28a2-4e3b-95d1-90d6f63c7882
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/fe0b2864-5709-405a-a2c2-e09386ae540e
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/ff612b0a-093a-455d-89fe-7534c7624e5f
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/24501377-5f21-4fc2-a910-5c960797fd01
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/5004bb8c-c6c0-4340-8200-c430da77905e
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/5a5f5727-580c-4008-a9bf-22c1d31e87d7
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/68f92edd-e540-40d0-af82-97cee084eb92
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/7c39a885-07c0-4c69-a4e0-57d755ab7d4a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/aa3cd0df-e01d-4596-b68a-75cca4d44559
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f892bbac-ad7f-44e6-aa6b-7877c692e977
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/1ecffa0e-09c7-43e4-a097-809c69b68939
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/42826a26-1d7b-4238-8d51-1ddee8f5ce93
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/b90658aa-fc54-4b61-a571-f84f88eed4b7
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/e0fc1af3-0593-49a2-9cff-325a93d9596f
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f4fd9135-5dc7-4e10-ac4b-b9d4545161c6
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2f15511a-fc51-4562-9c97-aca4e32ad16d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/42551651-20af-443f-8971-7789063233a3
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/9f9e4f54-5755-4789-92bd-50e385060489
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/e38628f0-d28a-41b2-80ca-db39ec204cd8
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f2f069c5-f0eb-4671-8887-7109fac6c5a5
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/3363f449-4a0c-4a55-a725-baa8b716ad84
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/b674567c-bcd9-4669-8dde-fdc6bc24dcc7
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/beec333c-a3ef-418d-b47a-b92fa8cac3e6
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/eb2a1fab-5746-42f7-a047-afcad6fbe704
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f6b48bf6-3cdd-4da9-895b-ee57571d8d59
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/fd892c0e-8126-4a41-883d-d97921f66c50
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/1e9955ec-0f08-4538-9305-e6c7ad70ba3a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/94579d46-89bc-41e6-9b0c-f7801a757aab
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d6a7841f-2ae6-47d4-9117-e8e26a4a990a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/fff8ea21-687e-41b2-9157-deecb7c408d5
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/412ed29b-9652-4d46-860c-039caaf4c721
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8b278539-a7a2-4ae3-a429-28f97b47dd26
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/9d7d2405-c096-4875-837b-0b1a543aff1c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/cec26a25-de2b-4e09-9a2d-3a848b8d0ac7
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d9a4e602-54e4-4741-8794-3049b20dcc4a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2110e3d3-6f53-4a7a-a224-0b58401ae402
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/39d87ea2-5844-489a-b421-ccb24486cc44
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/79d0b441-e120-4aba-b111-57bdd053545d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/bc63ed10-8437-4126-8466-5a04da923b2b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d1b782ce-4375-4837-95d8-729b704c5b05
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/db53dd68-1bfe-40fa-86fb-656c120314ed
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/c0e6fd66-9a81-4fb1-a41f-53efcef376de
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/fe8dec90-2ebd-4797-baaf-1ad603d3b143
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/32fd96a3-cdca-4d3f-af12-be3b73f47fdd
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/4b612c1e-105e-432d-a580-649f0814a395
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/6acfeeb3-06ef-41ad-8f31-d65bcc88529a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8b4e2e2d-1889-430e-b0a3-d855209acc1a
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8d2fb0a1-108f-464f-8c21-0e49e0dbe0ea
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/9a4ca69a-24af-4e6a-bb7f-da340702cbfa
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/0bd2bdae-666d-49ed-be23-ddd7904fbd45
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2f798250-0bc4-449a-ab9a-f1e1b995d5c6
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/9f4802ea-1ecb-463d-aa58-5b534ecf5eb0
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/26b315be-abfb-40c4-815d-1881ce7e1f32
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/53f09cb8-06b6-4cc6-91c2-bcf3790e26ee
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/546e877f-acf4-43de-a4b5-19bcea3bd846
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/5bd422cd-194b-40c9-9ace-506e003fc325
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/c4571d1d-9f1d-4cfd-92d1-35f4f0c21c8b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/eea01f67-8076-45d6-be5d-0f4e397670c0
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/4817ec7c-da98-4c90-b5e0-de65dd830e32
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/52f872bc-f578-457d-81ae-685a1ee17565
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/7ecff336-01ed-45e0-9d68-7ece00130f41
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/9210a1c7-a92d-4856-b1ef-1359c89e8fa7
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/a73fde6e-b074-41bc-99b1-5491a1e6dc7c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d7bc381c-b277-4f18-a967-d3dec8d0fc72
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/1c659a8a-6c3e-494d-a4ed-0867750c8207
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/4247417f-33e9-4f2d-9c2b-5ba49a3295aa
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/4e35ddfb-46e1-480a-b27b-ba6b0425ab82
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/861bf7d9-b2bf-4805-bb08-794f70e7f5b8
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/b18bd108-6047-45ea-8b98-acc082baddef
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/e1139a48-ce66-42eb-beff-113cc7545e4e
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f5137af7-7800-4e42-a899-a0cd768fcf2b
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/129f4420-2dcc-4d59-8814-8608af895979
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/38b73826-569d-42ee-8902-3c33d936ddb2
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/3ad8bc6d-e420-4ac8-8bdb-5c5437ba4a05
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/610e4462-cf8e-4c3f-ada9-54ebaed1f2b1
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/be4242ae-dd16-41ea-8fa0-efc5cfce5e9c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/2a68e415-424f-4084-b9f7-bdd70aa7e727
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/771b6314-a1b4-47d7-a1c2-dd3323b34161
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/896bff24-00be-4185-bcce-150bd340947d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/ec78ff0a-86e8-4ddd-8291-77d0bb3697e6
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/6de3f685-a967-471f-8395-344d9f2429a9
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/7eca5c07-5bc3-40f9-80c1-389bdc33c533
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/aafc3eb0-b10b-489e-abc6-985d0326e25e
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d55cfef5-2390-4477-81d9-16ddcb1e4473
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/eb2c915e-c178-498c-89d3-aa34f3d86cdc
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/faa9892c-33a1-4292-8cd0-7b2ad439ca41
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/22f94485-36e2-4642-b1b1-30fb5946a29d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/578dd8e6-843f-44fd-9336-a02d3c543a86
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/72acd718-b0b9-4bc4-9938-4a655ab547c9
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/9cb72fe5-b8c5-43cf-a6ba-5272f1a49806
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/b0343f92-2a08-4ef4-961a-58f25655c66d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/d04a8cce-bf6e-4358-9087-cfae23338321
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/f89df2bc-18e4-4637-8f12-5ce38f51d515
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/17035a9d-050d-41e2-97c3-5a10bd48eb07
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/351fd489-0f0a-493d-b245-15131000c3c5
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/726758f4-7702-4086-a27e-c679cc62848d
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/7ddd65e4-15d8-4aa4-8ed0-dff4455860ea
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/8349c027-fb57-43a7-bc62-40cc4bc2d170
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/c91cb94a-9ec9-40f0-a728-4c16ada2de3c
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/01e66e7d-2f88-4f2e-82de-02af80e87c65
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/529e8ccd-e3ea-4835-b93e-0c94993fa592
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/5f4c5a61-2293-4ebc-b0a4-af46ba51a0f5
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/7bb92687-f929-4a85-8b4e-cef442df0180
https://eventmobi.com/asm2019/agenda/95383873-2cbe-47a0-be6f-240ab7d5f373/a9b23e03-ca6b-4605-87b5-54d7b1466993'''.split("\n")


    year = 2019
    test = ArcticNet("https://eventmobi.com/asm"+str(year)+"/",debug=False,loadDelay=.5)
    test.loadJson("ArcticNetSpeakers(new).json")
    test.checkData()
    #test.startScrape()
    #test.getPosters()
    #test.goThroughLinks()
    #allArcticNetSpeakers = test.getSpeakers()
    #for speaker in allArcticNetSpeakers:
    #    print(speaker["name"])
    #with open("ArcticNetSpeakers(new)","w") as fout:
    #    json.dump(allArcticNetSpeakers,fout)
