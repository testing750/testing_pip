from urllib.request import Request, urlopen
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common import by
import time, datetime
import re
import json
import TackleboxScraper


class Cmos(TackleboxScraper.TackleBoxScraper):
    def __init__(self, url, debug=False):
        super().__init__(url, debug=debug)

    # Gets page buttons
    def get_button_elements(self):
        button_list = []
        pagination = self.driver.find_element_by_class_name("pagination-sm")
        button_containers = pagination.find_elements_by_tag_name("li")
        # Gets only the relevant buttons
        for button_container in button_containers:
            buttons = button_container.find_element_by_tag_name("a")
            if buttons.find_elements_by_tag_name("span"):
                button_list.append(buttons)
        return button_list

    def startScrape(self):
        speaker_list = []
        global company, page
        self.driver.get(self.url)

        button_list = self.get_button_elements()

        # Loops through all pages row by row
        for page in range(len(button_list)):
            fresh_button_list = self.get_button_elements()
            fresh_button_list[page].click()

            table_container = self.driver.find_element_by_id("rosterRecords")
            table = table_container.find_element_by_class_name("col-sm-12")
            rows = table.find_elements_by_tag_name("table")[1:]

            if len(rows) > 0:
                for item in rows:
                    rows2 = item.find_element_by_tag_name("tbody")
                    title = rows2.find_elements_by_tag_name("td")[1]
                    link = title.find_element_by_tag_name("a")

                    # Store the starting window in a variable so we can switch back to it later
                    base_window = self.driver.window_handles[0]
                    link.click()
                    # Switch to the new window handle, it always gets appended to the end of the array of windows
                    self.driver.switch_to.window(self.driver.window_handles[1])

                    # Get names
                    info = self.driver.find_element_by_id("clientRelationRosterDetails")
                    name_elements = info.find_elements_by_tag_name("em")
                    names = []
                    for name_element in name_elements:
                        names.append(name_element.text)

                    # Get universities
                    university_container = info.find_element_by_class_name("style2")
                    split_university_strings = university_container.get_attribute("innerHTML").split("<br")
                    university_list = []
                    for university in split_university_strings[0:-1]:
                        university_list.append(university.split('</sup>')[1].split(',')[0])

                    # Get title
                    title_container = info.find_element_by_tag_name("p")
                    title = title_container.find_element_by_tag_name("strong").text

                    # Get description
                    details = info.find_element_by_class_name("style1").text

                    # Creates a new speaker or adds a presentation to an existing speaker
                    for count, name in enumerate(names):
                        speaker_id = self.__get_speaker_id(name, speaker_list)
                        if speaker_id is not None:
                            speaker_list[speaker_id]["presentations"].append({"pTitle": title, "pDetails": details})
                            pass
                        else:
                            speakerInfo = {
                                "name": name,
                                "company": university_list[count],
                                "jobTitle": "",
                                "presentations": [{
                                    "pTitle": title,
                                    "pDetails": details
                                }]
                            }
                            speaker_list.append(speakerInfo)

                    # Close the window when finished extracting info
                    self.driver.close()
                    # Switch back to the base window
                    self.driver.switch_to.window(base_window)

        # Prints the speakers' information
        for i in speaker_list:
            print(i)

        # Creates a JSON file for output
        json_object = json.dumps(speaker_list, indent=4)

        with open("speakers.json", "w") as outfile:
            outfile.write(json_object)

    # Helps enumerate each speaker by name
    def __get_speaker_id(self, speaker_name, speaker_list):
        for id, speaker in enumerate(speaker_list):
            if speaker['name'] == speaker_name:
                return id
        return None


if __name__ == "__main__":
    cmos = Cmos(
        'https://cmos.in1touch.org/client/relation_roster/clientRelationRosterView.html?clientRelationRosterId=133#',
        debug=True)
    cmos.startScrape()