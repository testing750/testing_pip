from setuptools import setup

setup(
    name='tacklebox_scraper',
    packages=['tacklebox_scraper'],
    description='Webscraping package designed for Tacklebox',
    version='0.1',
    url='',
    author='PiscesRPM',
    author_email='',
    keywords=['pip','tacklebox','scraper'],
    install_requires=[
        'selenium',
    ],
    package_data={'tacklebox_scraper': ['data/*.json']},
    )